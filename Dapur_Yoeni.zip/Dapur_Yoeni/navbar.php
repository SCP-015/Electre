<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Link ke file CSS Bootstrap (CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Link ke file CSS Font Awesome (CDN) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Font untuk seluruh halaman -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Poppins:wght@400;600&display=swap" rel="stylesheet">

    <title>Document</title>
    <style>
        body {
            background: #ffeeb2;
        }

        /* Gaya untuk navbar */
        .navbar {
            position: fixed;
            top: 0;
            z-index: 1000;
            width: 100%;
            background: linear-gradient(135deg, #f39c12, #f39c12);
            backdrop-filter: blur(10px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease-in-out;
        }

        .navbar:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .navbar .navbar-brand {
            color: #fff;
        }

        .navbar .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.1rem;
        }

        .navbar .navbar-nav .nav-link:hover {
            color: #ffe499 !important;
        }

        .cart-icon-wrapper {
            position: relative;
            cursor: pointer;
        }

        .cart-icon {
            font-size: 2rem;
            color: #fff;
        }

        .cart-badge {
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: #dc3545;
            color: white;
            border-radius: 50%;
            padding: 5px 10px;
            font-size: 0.8rem;
        }

        /* Responsive tweaks for mobile */
        @media (max-width: 768px) {
            .navbar .navbar-collapse {
                text-align: center;
            }

            .cart-icon-wrapper {
                margin-left: auto;
                display: flex;
                align-items: center;
                justify-content: center;
            }
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container-fluid">
            <!-- Logo on the left -->
            <a class="navbar-brand" href="index">
                <img src="image/yoeni.png" alt="Logo" style="height: 40px; width: auto;">
            </a>

            <!-- Navbar toggler button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="galeri">Galeri</a>
                    </li>
                </ul>

                <!-- Cart Icon -->
                <div class="cart-icon-wrapper" onclick="window.location.href='cart';">
                    <i class="fas fa-shopping-cart cart-icon"></i>
                    <span class="cart-badge" id="total-products-badge">
                        <?php
                        $totalProducts = 0;
                        if (isset($_SESSION['cart'])) {
                            $totalProducts = count($_SESSION['cart']);
                        }
                        echo $totalProducts;
                        ?>
                    </span>
                </div>
            </div>
        </div>
    </nav>

    <!-- Include Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Include Font Awesome JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>