<?php
session_start();
include('koneksi.php');

// Cek apakah order_id tersedia dalam session
if (isset($_SESSION['order_id'])) {
    $order_id = $_SESSION['order_id'];

    // Ambil data pesanan berdasarkan order_id dari database
    $query = "SELECT * FROM pesanan WHERE order_id = '$order_id'";
    $result = mysqli_query($conn, $query);

    // Jika data ditemukan
    if ($result && mysqli_num_rows($result) > 0) {
        $pesanan = mysqli_fetch_assoc($result);
        unset($_SESSION['cart']);

        // Ambil detail produk berdasarkan order_id
        $detail_query = "SELECT * FROM tabel_detail_pesanan WHERE order_id = '$order_id'";
        $detail_result = mysqli_query($conn, $detail_query);
        $details = [];
        while ($row = mysqli_fetch_assoc($detail_result)) {
            $details[] = $row;
        }
    } else {
        echo "<div class='container text-center mt-5'><h3 class='text-danger'>Pesanan dengan Order ID <strong>" . htmlspecialchars($order_id) . "</strong> tidak ditemukan.</h3></div>";
        exit();
    }
} else {
    // Jika order_id tidak ada dalam session, redirect ke halaman utama (index.php)
    header("Location: home");
    exit();
}

// Tutup koneksi database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice - #<?php echo htmlspecialchars($pesanan['order_id']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .invoice-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 70%;
            margin: auto;
        }

        .invoice-header,
        .invoice-body,
        .invoice-footer {
            margin-bottom: 20px;
        }

        .invoice-header h1 {
            text-align: center;
            margin: 0;
            color: #333;
        }

        .invoice-header hr {
            margin-top: 10px;
            border: 1px solid #ddd;
        }

        .invoice-body .section-title {
            font-weight: bold;
            margin-top: 10px;
        }

        .invoice-body table {
            width: 100%;
            border-collapse: collapse;
        }

        .invoice-body table,
        .invoice-body th,
        .invoice-body td {
            border: 1px solid #ddd;
        }

        .invoice-body th,
        .invoice-body td {
            padding: 8px;
            text-align: left;
        }

        .invoice-body th {
            background-color: #f2f2f2;
        }

        .total-row {
            font-weight: bold;
        }

        .invoice-footer {
            text-align: center;
            font-size: 14px;
            color: #888;
        }

        .status {
            font-weight: bold;
            color: #fff;
            padding: 5px;
            border-radius: 3px;
        }

        .status-paid {
            background-color: green;
        }

        .status-processing {
            background-color: #ffcc00;
        }

        .status-shipping {
            background-color: #1e90ff;
        }

        .status-completed {
            background-color: #28a745;
        }

        .status-pending {
            background-color: #b2b2b2;
        }

        .status-canceled {
            background-color: red;
        }

        .action-buttons {
            text-align: center;
            margin-top: 20px;
        }

        .action-buttons a {
            text-decoration: none;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 5px;
            color: #fff;
            font-weight: bold;
        }

        .btn-primary {
            background-color: #007bff;
        }

        .btn-whatsapp {
            background-color: #25d366;
        }

        .payment-warning {
            background-color: #ffecb3;
            padding: 15px;
            text-align: center;
            margin-top: 20px;
            border-radius: 5px;
            color: #856404;
        }

        /* Responsif untuk perangkat mobile */
        @media (max-width: 768px) {
            .container {
                width: 95%;
            }

            .form-container,
            .invoice-container {
                width: 100%;
                padding: 15px;
            }

            .invoice-header h1 {
                font-size: 1.5em;
            }

            .invoice-body .section-title {
                font-size: 1.2em;
            }

            .invoice-body table th,
            .invoice-body table td {
                padding: 6px;
                font-size: 14px;
            }

            .action-buttons a {
                font-size: 14px;
                padding: 8px 16px;
            }
        }

        /* Responsif untuk perangkat lebih kecil (mobile) */
        @media (max-width: 480px) {

            .invoice-container {
                margin-top: 30px;
            }

            .form-container input,
            .form-container button {
                width: 250px;
                padding: 12px;
                margin: 5px 0;
            }

            .invoice-header h1 {
                font-size: 1.3em;
            }

            .invoice-body table th,
            .invoice-body table td {
                font-size: 12px;
                padding: 4px;
            }

            .payment-warning {
                font-size: 14px;
                padding: 10px;
            }

            .action-buttons a {
                font-size: 13px;
                padding: 8px 15px;
            }
        }
    </style>
</head>

<body>
    <div class="invoice-container">
        <!-- Invoice Header -->
        <div class="invoice-header">
            <h1>INVOICE</h1>
            <hr>
            <p><strong>Nomor Invoice</strong>: <?php echo htmlspecialchars($pesanan['order_id']); ?></p>
            <p><strong>Tanggal Pembelian</strong>: <?php echo date('d F Y', strtotime($pesanan['created_at'])); ?></p>
        </div>

        <!-- Invoice Body -->
        <div class="invoice-body">
            <p><strong>Pelanggan</strong>: <?php echo htmlspecialchars($pesanan['nama']); ?></p>
            <p><strong>Alamat Pengiriman</strong>: <?php echo htmlspecialchars($pesanan['alamat']); ?></p>

            <div class="section-title">DETAIL PESANAN:</div>
            <table>
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Kuantitas</th>
                        <th>Harga</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;
                    foreach ($details as $detail) {
                        $subtotal = $detail['harga'] * $detail['jumlah'];
                        $total += $subtotal;
                        echo "<tr>
                            <td>" . htmlspecialchars($detail['nama_produk']) . "</td>
                            <td>" . htmlspecialchars($detail['jumlah']) . "</td>
                            <td>Rp " . number_format($detail['harga'], 0, ',', '.') . "</td>
                            <td>Rp " . number_format($subtotal, 0, ',', '.') . "</td>
                        </tr>";
                    }

                    // Generate a random two digits number between 1 and 99
                    $randomNumber = rand(1, 99);

                    // Add random number to the total amount
                    $totalWithRandom = $total + $randomNumber;
                    ?>

                    <tr class="total-row">
                        <td colspan="3" style="text-align: right;">Subtotal</td>
                        <td>Rp <?php echo number_format($total, 0, ',', '.'); ?></td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="3" style="text-align: right;"><strong>TOTAL</strong></td>
                        <td><strong>Rp <?php echo number_format($total, 0, ',', '.'); ?></strong></td>
                    </tr>
                </tbody>
            </table>

            <div class="section-title">REKENING PEMBAYARAN:</div>
            <p><strong>Bank BCA</strong>: 3490908349</p>
            <p><strong>Atas Nama</strong>: Yuniarti</p>

            <div class="section-title">STATUS PEMBAYARAN:</div>
            <p><span class="status <?php echo ($pesanan['status_bayar'] == 'Lunas') ? 'status-paid' : ($pesanan['status_bayar'] == 'Belum Bayar' ? 'status-canceled' : 'status-pending'); ?>">
                    <?php echo ucfirst(htmlspecialchars($pesanan['status_bayar'])); ?>
                </span></p>

            <div class="section-title">STATUS PESANAN:</div>
            <p><span class="status <?php
                                    echo ($pesanan['status_pesanan'] == 'Pending') ? 'status-pending' : ($pesanan['status_pesanan'] == 'Sedang Diproses' ? 'status-processing' : ($pesanan['status_pesanan'] == 'Dalam Pengiriman' ? 'status-shipping' : ($pesanan['status_pesanan'] == 'Selesai' ? 'status-completed' : 'status-canceled'))); ?>">
                    <?php echo htmlspecialchars($pesanan['status_pesanan']); ?>
                </span></p>

            <!-- Peringatan Pembayaran -->
            <?php if ($pesanan['status_bayar'] != 'Lunas') { ?>
                <div class="payment-warning">
                    <strong>Harap melakukan pembayaran sejumlah Rp <?php echo number_format($totalWithRandom, 0, ',', '.'); ?> dan simpan bukti pembayaran Anda.</strong>
                </div>
            <?php } ?>

            <!-- Action Buttons -->
            <div class="action-buttons">
                <!-- Tombol Lanjut Belanja -->
                <a href="produk" class="btn btn-primary">Lanjut Belanja</a>

                <!-- Tombol WhatsApp -->
                <a href="https://wa.me/6282362584235?text=Halo%2C%20saya%20ingin%20melakukan%20pembayaran%20dengan%20nomor%20invoice%20ORD<?php echo $pesanan['order_id']; ?>" class="btn btn-whatsapp" target="_blank">
                    Hubungi via WhatsApp
                </a>
            </div>
        </div>

        <!-- Invoice Footer -->
        <div class="invoice-footer">
            <p>Terima kasih telah berbelanja di Dapur Yoeni</p>
        </div>
    </div>
</body>

</html>