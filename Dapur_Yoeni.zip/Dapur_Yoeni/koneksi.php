<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'dapur_yoeni';

// Membuat koneksi
$conn = mysqli_connect($host, $user, $password, $dbname);

// Cek koneksi
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
