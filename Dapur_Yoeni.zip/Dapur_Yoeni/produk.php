<?php
session_start();
include_once 'koneksi.php'; // Koneksi ke database

// Cek apakah quantity lebih besar dari 0 sebelum menambah produk ke keranjang
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Periksa apakah quantity lebih besar dari 0
    if ($quantity > 0) {
        // Ambil detail produk dari database
        $stmt = $conn->prepare("SELECT nama, harga FROM produk WHERE id = ?");
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $product = $result->fetch_assoc();

            // Periksa apakah produk sudah ada di dalam session keranjang
            if (!isset($_SESSION['cart'][$productId])) {
                // Tambahkan produk baru ke dalam session
                $_SESSION['cart'][$productId] = [
                    'name' => $product['nama'],
                    'price' => $product['harga'],
                    'quantity' => $quantity
                ];
            } else {
                // Jika produk sudah ada, tambahkan kuantitasnya
                $_SESSION['cart'][$productId]['quantity'] += $quantity;
            }
        }
    } else {
        // Jika quantity <= 0, beri tahu pengguna
        echo '<script>alert("Silakan masukkan jumlah produk yang valid (lebih dari 0)");</script>';
    }

    // Redirect ke halaman produk list setelah menambahkan
    header('Location: produk');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <title>Produk List</title>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
        }

        .navbar {
            position: fixed;
            top: 0;
            z-index: 1000;
            width: 100%;
            background: linear-gradient(135deg, #f39c12, #f39c12);
            backdrop-filter: blur(10px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease-in-out;
        }

        .navbar:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .navbar .navbar-brand {
            color: #fff;
        }

        .navbar .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.1rem;
        }

        .navbar .navbar-nav .nav-link:hover {
            color: #ffe499 !important;
        }

        .cart-icon-wrapper {
            position: relative;
            cursor: pointer;
        }

        .cart-icon {
            font-size: 2rem;
            color: #fff;
        }

        .cart-badge {
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: #dc3545;
            color: white;
            border-radius: 50%;
            padding: 5px 10px;
            font-size: 0.8rem;
        }

        .category-section {
            margin-top: 100px;
            margin-bottom: 50px;
        }

        .category-section h2 {
            font-size: 2rem;
            color: #f39c12;
            text-transform: uppercase;
            border-bottom: 3px solid #f39c12;
            padding-bottom: 12px;
            margin-bottom: 20px;
        }

        .category-section .card {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
            background: #fff;
            border: none;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .category-section .card:hover {
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
        }

        .category-section .card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-bottom: 4px solid #f39c12;
            transition: transform 0.3s ease;
        }

        .category-section .card-body {
            padding: 20px;
            text-align: center;
            flex-grow: 1;
        }

        .category-section .card-title {
            font-size: 1.4rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .category-section .card-text {
            font-size: 1.1rem;
            color: #333;
            margin-bottom: 15px;
            font-weight: 500;
        }

        .quantity-container {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            width: 100%;
        }

        .quantity-input {
            width: 70px;
            height: 40px;
            text-align: center;
            font-size: 1.2rem;
            border-radius: 8px;
            border: 1px solid #ccc;
            outline: none;
            margin-right: 10px;
        }

        .btn-add-to-cart {
            background-color: #f39c12;
            color: white;
            font-size: 1rem;
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-add-to-cart i {
            display: inline-block;
            margin-right: 8px;
        }

        .btn-add-to-cart:hover {
            background-color: #e67e22;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        /* Media queries untuk membuat halaman responsif */
        @media (max-width: 1024px) {
            .category-section .card-body {
                padding: 15px;
            }

            .quantity-container {
                flex-direction: column;
                align-items: center;
            }

            .quantity-input {
                font-size: 1rem;
                width: 60px;
            }

            .btn-add-to-cart {
                font-size: 0.9rem;
                padding: 8px 16px;
            }

            .category-section .col-md-3 {
                width: 48%;
                margin-bottom: 20px;
            }
        }

        @media (max-width: 768px) {
            .category-section .card {
                margin-bottom: 20px;
            }

            .category-section .col-md-3 {
                width: 100%;
                margin-bottom: 20px;
            }

            .quantity-input {
                width: 60px;
            }

            .btn-add-to-cart {
                font-size: 1rem;
                padding: 12px 18px;
            }
        }

        footer {
            background-color: #333;
            color: white;
            padding: 40px 0;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }

        footer a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
        }

        footer a:hover {
            color: #f39c12;
        }

        footer .social-icons a {
            color: white;
            margin-right: 10px;
        }

        footer .social-icons a:hover {
            color: #f39c12;
        }

        footer .col-md-3 ul li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light initial-load" data-aos="slide-down" data-aos-duration="1000" data-aos-easing="ease-in-out">
        <div class="container-fluid">
            <!-- Logo on the left -->
            <a class="navbar-brand" href="home">
                <img src="image/yoeni.png" alt="Logo" style="height: 40px; width: auto;">
            </a>

            <!-- Navbar links on the right -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="galeri">Galeri</a>
                    </li>
                </ul>
                <div class="cart-icon-wrapper" onclick="window.location.href='cart';">
                    <i class="fas fa-shopping-cart cart-icon"></i>
                    <span class="cart-badge" id="total-products-badge">
                        <?php
                        // Menghitung jumlah produk unik di keranjang
                        $totalProducts = 0;
                        if (isset($_SESSION['cart'])) {
                            $totalProducts = count($_SESSION['cart']); // Hitung jumlah item unik di keranjang
                        }
                        echo $totalProducts;
                        ?>
                    </span>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-5 mb-5">
        <?php
        // Ambil semua kategori dari database
        $categoriesQuery = "SELECT id, nama FROM kategori";
        $categoriesResult = $conn->query($categoriesQuery);

        // Loop untuk menampilkan produk berdasarkan kategori
        while ($category = $categoriesResult->fetch_assoc()) {
            $kategori_id = $category['id'];
            $kategori_nama = $category['nama'];

            echo "<section id='category-{$kategori_id}' class='category-section'>";
            echo "<h2 class='my-4'>{$kategori_nama}</h2>";
            echo "<div class='row'>";

            // Query untuk mengambil produk berdasarkan kategori
            $stmt = $conn->prepare("SELECT * FROM produk WHERE kategori_id = ?");
            $stmt->bind_param("i", $kategori_id);
            $stmt->execute();
            $result = $stmt->get_result();

            // Tampilkan produk dalam kategori ini
            while ($row = $result->fetch_assoc()) {
                echo '<div class="col-md-3 mb-4">
                    <div class="card">
                        <img src="uploads/' . htmlspecialchars($row['gambar']) . '" alt="' . htmlspecialchars($row['nama']) . '" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">' . htmlspecialchars($row['nama']) . '</h5>
                            <p class="card-text">Rp ' . number_format($row['harga'], 0, ',', '.') . '</p>
                            <form method="POST" action="produk">
                                <input type="hidden" name="product_id" value="' . $row['id'] . '">
                                <div class="quantity-container">
                                    <input type="number" class="quantity-input" name="quantity" value="0" min="1" max="999">
                                    <button type="submit" class="btn-add-to-cart">
                                        <i class="fas fa-shopping-cart"></i> Add to Cart
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>';
            }

            echo "</div>"; // Tutup row
            echo "</section>"; // Tutup section kategori
        }
        ?>
    </div>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <img src="image/yoeni.png" alt="UMKM Logo" style="width: 100px;">
                    <h5 style="margin-top: 15px;">Dapur Yoeni</h5>
                    <p style="font-style: italic;">Supplier Sirup Lemon dengan Kualitas Tinggi</p>
                </div>

                <div class="col-md-3">
                    <h5>Reseller</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Beranda</a></li>
                        <li><a href="#">Produk Kami</a></li>
                        <li><a href="testi">Ulasan</a></li>
                        <li><a href="cek">Cek Pesanan</a></li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <h5>Informasi</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Tentang Kami</a></li>
                        <li><a href="#">Syarat & Ketentuan</a></li>
                        <li><a href="#">Kebijakan Privasi</a></li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <h5>Kontak</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt"></i> Jl. Pijer Podi No.117, Sempakata, Kec. Medan Selayang, Sumatera Utara 20132</li>
                        <li><i class="fas fa-phone-alt"></i> <a href="https://wa.me/082362584235">+62 823-6258-4235</a></li>
                    </ul>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#"><i class="fab fa-twitter fa-lg"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center" style="margin-top: 20px;">
            <p>&copy; 2024 Dapur Yoeni. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Script JS untuk validasi quantity -->
    <script>
        document.querySelectorAll('form').forEach(function(form) {
            form.addEventListener('submit', function(e) {
                var quantityInput = form.querySelector('input[name="quantity"]');
                var quantity = parseInt(quantityInput.value);

                if (quantity <= 0) {
                    e.preventDefault(); // Mencegah form submit
                    alert('Silakan masukkan jumlah produk yang valid (lebih dari 0)');
                }
            });
        });
    </script>
</body>

</html>