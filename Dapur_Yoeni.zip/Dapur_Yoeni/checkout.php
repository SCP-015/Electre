<?php
session_start(); // Pastikan session dimulai
include('koneksi.php');

// Generate random order_id
$order_id = "ORD" . rand(10000, 99999); // ID acak

// Cek jika data telah di-submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Data pemesan
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $no_hp = mysqli_real_escape_string($conn, $_POST['no_hp']);

    // Ambil data keranjang dari session (karena sebelumnya kita menggunakan session)
    $cart_data = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
    $total_harga = $_POST['total_harga'];

    // Query untuk tabel_pesanan
    $query_pesanan = "INSERT INTO pesanan (order_id, nama, alamat, no_hp, total_harga, status_bayar, status_pesanan)
                      VALUES ('$order_id', '$nama', '$alamat', '$no_hp', '$total_harga', 'Belum Bayar', 'Pending')";

    // Eksekusi query tabel_pesanan
    if (mysqli_query($conn, $query_pesanan)) {
        // Simpan detail pesanan ke tabel_detail_pesanan
        foreach ($cart_data as $productId => $details) {
            $nama_produk = mysqli_real_escape_string($conn, $details['name']);
            $jumlah = (int)$details['quantity'];
            $harga = (float)$details['price'];
            $total = $jumlah * $harga;

            $query_detail = "INSERT INTO tabel_detail_pesanan (order_id, nama_produk, jumlah, harga, total)
                             VALUES ('$order_id', '$nama_produk', $jumlah, $harga, $total)";

            // Eksekusi query tabel_detail_pesanan
            if (!mysqli_query($conn, $query_detail)) {
                echo "Error menyimpan detail pesanan: " . mysqli_error($conn);
                exit;
            }
        }

        // Simpan order_id ke session
        $_SESSION['order_id'] = $order_id;

        // Redirect ke halaman pembayaran
        header("Location: payment");
        exit;
    } else {
        echo "Error: " . $query_pesanan . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS untuk background dan responsivitas -->
    <style>
        body {
            background-color: #feeeb1;
            /* Mengubah warna latar belakang halaman */
        }

        .container {
            max-width: 800px;
            /* Membatasi lebar container agar responsif */
        }

        .form-control {
            font-size: 1rem;
            /* Ukuran font form control lebih besar */
        }

        /* Responsif untuk perangkat mobile */
        @media (max-width: 768px) {
            .container {
                padding: 0 15px;
                /* Menambahkan padding pada container di perangkat kecil */
            }

            .form-control {
                font-size: 0.9rem;
                /* Menyesuaikan ukuran font untuk perangkat kecil */
            }
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Isi Data Pesanan Anda</h1>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form method="POST" action="checkout.php" class="p-4 border rounded bg-light shadow">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama</label>
                        <input type="text" class="form-control" name="nama" id="nama" required>
                    </div>
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <textarea class="form-control" name="alamat" id="alamat" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="no_hp" class="form-label">No HP</label>
                        <input type="number" class="form-control" name="no_hp" id="no_hp" required>
                    </div>

                    <!-- Data cart dari session -->
                    <input type="hidden" name="cart_data" id="cart_data">
                    <input type="hidden" name="total_harga" id="total_harga">

                    <div class="d-grid">
                        <button type="submit" class="btn" style="background-color: #f39c12;">Bayar Sekarang</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Bootstrap Bundle JS (Popper + Bootstrap) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Ambil data keranjang dari session PHP (karena menggunakan PHP, kita simpan di session)
        const cart = <?php echo json_encode($_SESSION['cart'] ?? []); ?>;
        let totalHarga = 0;

        // Hitung total harga
        for (const [productId, details] of Object.entries(cart)) {
            totalHarga += details.quantity * details.price;
        }

        // Isi field cart_data dan total_harga di form
        document.getElementById("cart_data").value = JSON.stringify(cart);
        document.getElementById("total_harga").value = totalHarga;
    </script>
</body>

</html>