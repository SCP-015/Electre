<?php
include 'koneksi.php'; // Menghubungkan ke database

// Query untuk mengambil data ulasan
$query = "SELECT * FROM reviews ORDER BY date DESC";
$result = mysqli_query($conn, $query);

// Proses formulir jika data diterima
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Mengambil data dari formulir
    $name = htmlspecialchars($_POST['name']);
    $rating = $_POST['rating'];
    $comment = htmlspecialchars($_POST['comment']);

    // Query untuk memasukkan data ke database
    $insertQuery = "INSERT INTO reviews (name, rating, comment, date) VALUES ('$name', '$rating', '$comment', NOW())";
    if (mysqli_query($conn, $insertQuery)) {
        echo "<script>alert('Testimoni berhasil ditambahkan!'); window.location.href='testi';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan. Silakan coba lagi.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ulasan Produk</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #feeeb1;
            color: #000000;
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
        }

        .container {
            margin-top: 70px;
        }

        h1 {
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 20px;
        }

        .col-md-4 {
            padding: 10px;
        }

        .review-card {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            color: #333;
            height: 100%;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .review-card h5,
        .review-card p,
        .review-stars {
            margin: 0;
            padding: 0;
        }

        .review-stars {
            color: #FFD700;
        }

        .no-reviews {
            text-align: center;
            font-size: 18px;
            margin-top: 20px;
            background-color: #FFD1A9;
            padding: 10px;
            border-radius: 10px;
            color: #333;
        }

        .form-container {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
            margin-bottom: 50px;
        }

        .form-container input,
        .form-container textarea {
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 class="text-center">Ulasan Produk Kami</h1>

        <!-- Tombol Kembali -->
        <a href="home" class="btn btn-secondary mb-3">Kembali ke Halaman Utama</a>

        <!-- Menampilkan Ulasan -->
        <div class="row mt-5">
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="col-md-4">';
                    echo '<div class="review-card">';
                    echo '<div class="d-flex align-items-center gap-3">';
                    echo '<div>';
                    echo '<h5>' . htmlspecialchars($row['name']) . '</h5>';
                    echo '<p>' . date('d M Y, H:i:s', strtotime($row['date'])) . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '<div class="review-stars">';
                    for ($i = 0; $i < $row['rating']; $i++) {
                        echo '<i class="bi bi-star-fill"></i>';
                    }
                    for ($i = $row['rating']; $i < 5; $i++) {
                        echo '<i class="bi bi-star"></i>';
                    }
                    echo '</div>';
                    echo '<p>' . htmlspecialchars($row['comment']) . '</p>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<div class="col-12">';
                echo '<div class="no-reviews">Belum ada ulasan.</div>';
                echo '</div>';
            }
            ?>
        </div>

        <!-- Formulir untuk Testimoni -->
        <div class="form-container">
            <h3>Tambah Testimoni</h3>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="name" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="rating" class="form-label">Rating</label>
                    <select class="form-select" id="rating" name="rating" required>
                        <option value="1">1 Bintang</option>
                        <option value="2">2 Bintang</option>
                        <option value="3">3 Bintang</option>
                        <option value="4">4 Bintang</option>
                        <option value="5">5 Bintang</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="comment" class="form-label">Komentar</label>
                    <textarea class="form-control" id="comment" name="comment" rows="4" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Kirim Testimoni</button>
            </form>
        </div>

    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.8.3/font/bootstrap-icons.min.css">
</body>

</html>