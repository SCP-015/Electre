<?php
require '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);

    if (!empty($kategori)) {
        $query = "INSERT INTO kategori (nama) VALUES ('$kategori')";
        if (mysqli_query($conn, $query)) {
            echo json_encode(['status' => 'success', 'message' => 'Kategori berhasil disimpan']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan kategori']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Nama kategori tidak boleh kosong']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
