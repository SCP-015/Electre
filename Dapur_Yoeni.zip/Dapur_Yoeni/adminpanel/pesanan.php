<?php require 'session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <title>Daftar Pesanan</title>
</head>

<style>
    .no-decoration {
        text-decoration: none;
    }

    .text-center-all td {
        text-align: center;
        vertical-align: middle;
    }

    .table thead th {
        text-align: center;
        vertical-align: middle;
        padding: 12px 8px;
    }
</style>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="home">DaYoen Adminpanel</a>
            <!-- Button to toggle navbar on mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link me-4" href="home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="kategori">Kategori</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="pesanan">Pesanan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="logout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Kontainer Utama -->
    <div class="container mt-5">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php" class="no-decoration text-muted">
                        <i class="fas fa-home"></i> Home
                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Pesanan</li>
            </ol>
        </nav>

        <!-- Header dan Pencarian -->
        <div class="mt-4 d-flex justify-content-between align-items-center">
            <h2>Daftar Pesanan</h2>
            <div class="input-group" style="width: 300px;">
                <input type="text" id="searchPesanan" class="form-control" placeholder="Cari pesanan...">
                <button class="btn btn-outline-secondary" id="searchBtn" type="button">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>

        <!-- Tabel Pesanan -->
        <div class="table-responsive mt-3">
            <table class="table table-bordered" style="table-layout: fixed; width: 100%;">
                <thead class="table-light text-center">
                    <tr>
                        <th class="text-center" style="width: 5%;">No.</th>
                        <th style="width: 10%;">Order ID</th>
                        <th style="width: 15%;">Nama Pelanggan</th>
                        <th style="width: 20%;">Alamat</th>
                        <th style="width: 12%;">No. HP</th>
                        <th style="width: 12%;">Status Pembayaran</th>
                        <th style="width: 10%;">Status Pesanan</th>
                        <th style="width: 10%;">Tanggal Buat</th>
                        <th class="text-center" style="width: 10%;">Detail Pesanan</th>
                    </tr>
                </thead>
                <tbody id="pesananTable" class="table-striped text-center-all">
                </tbody>
            </table>
        </div>

        <!-- Script -->
        <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../fontawesome/js/all.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            $(document).ready(function() {
                loadPesanan();

                function loadPesanan(search = "") {
                    $.ajax({
                        url: "load_pesanan.php", // Endpoint untuk ambil data pesanan
                        method: "GET",
                        data: {
                            search: search
                        },
                        dataType: "json",
                        success: function(data) {
                            var pesananTable = $("#pesananTable");
                            pesananTable.empty();

                            if (data.length === 0) {
                                pesananTable.append('<tr><td colspan="9" class="text-center">Tidak ada data Pesanan</td></tr>');
                            } else {
                                data.forEach(function(item, index) {
                                    var row = `
                                <tr>
                                    <td class="text-center">${index + 1}</td>
                                    <td>${item.order_id}</td>
                                    <td>${item.customer_name}</td>
                                    <td>${item.alamat}</td>
                                    <td>${item.no_hp}</td>
                                    <td>${item.status_bayar}</td>
                                    <td>${item.status_pesanan}</td>
                                    <td>${item.created_at}</td>
                                    <td class="text-center">
                                        <a href="detail_pesanan.php?p=${item.order_id}" class="btn btn-primary btn-sm" data-bs-toggle="tooltip" title="Lihat Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>`;
                                    pesananTable.append(row);
                                });
                            }
                        }
                    });
                }

                // Event Pencarian
                $("#searchPesanan").on("input", function() {
                    var search = $(this).val().trim();
                    loadPesanan(search);
                });

                // Reset Pencarian
                $("#searchBtn").on("click", function() {
                    $("#searchPesanan").val('');
                    loadPesanan();
                });
            });
        </script>
</body>

</html>