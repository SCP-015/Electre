<?php require 'session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.min.css">
    <title>Kategori</title>
    <style>
        .no-decoration {
            text-decoration: none;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="home">DaYoen Adminpanel</a>
            <!-- Button to toggle navbar on mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link me-4" href="home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="kategori">Kategori</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="pesanan">Pesanan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="logout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="../adminpanel" class="no-decoration text-muted">
                        <i class="fas fa-home"></i> Home
                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    Kategori
                </li>
            </ol>
        </nav>

        <!-- Form untuk Menambah Kategori -->
        <div class="my-4 col-12 col-md-6 col-lg-4">
            <h3>Tambah Kategori</h3>
            <form id="kategoriForm">
                <div>
                    <input type="text" id="kategori" name="kategori" class="form-control" placeholder="Nama Kategori">
                </div>
                <div class="mt-2">
                    <button class="btn btn-primary w-100" type="submit">Simpan</button>
                </div>
            </form>
            <div id="alertMsg" class="mt-3"></div>
        </div>

        <!-- Pencarian Kategori -->
        <div class="mt-4 d-flex justify-content-between align-items-center">
            <h2>Daftar Kategori</h2>
            <div class="input-group" style="max-width: 300px;">
                <input type="text" id="searchKategori" class="form-control" placeholder="Cari kategori...">
                <button class="btn btn-outline-secondary" id="searchBtn" type="button">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>

        <!-- Tabel Kategori -->
        <div class="table-responsive mt-3">
            <table class="table table-bordered" style="table-layout: fixed; width: 100%;">
                <thead class="table-light text-center">
                    <tr>
                        <th class="text-center" style="width: 10%;">No.</th>
                        <th style="width: 65%;">Nama Kategori</th>
                        <th class="text-center" style="width: 30%;">Aksi</th>
                    </tr>
                </thead>
                <tbody id="kategoriTable" class="table-striped">
                    <!-- Data kategori akan di-load di sini -->
                </tbody>
            </table>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Aktifkan tooltip di halaman
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });

            loadKategori();

            function loadKategori(search = "") {
                $.ajax({
                    url: "load_kategori.php",
                    method: "GET",
                    data: {
                        search: search
                    },
                    dataType: "json",
                    success: function(data) {
                        var kategoriTable = $("#kategoriTable");
                        kategoriTable.empty();

                        if (data.length === 0) {
                            kategoriTable.append('<tr><td colspan="3" class="text-center">Tidak ada data Kategori</td></tr>');
                        } else {
                            data.forEach(function(item, index) {
                                var row = ` 
                                    <tr>
                                        <td class="text-center">${index + 1}</td>
                                        <td>${item.nama}</td>
                                        <td class="text-center">
                                            <a href="edit_kategori?p=${item.id}" class="btn btn-success btn-sm" data-bs-toggle="tooltip" title="Edit">
                                                <i class="fas fa-pen"></i>
                                            </a>
                                            <a href="hapus_kategori?p=${item.id}" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus kategori ini?');">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                `;
                                kategoriTable.append(row);
                            });
                        }
                    }
                });
            }

            $("#kategoriForm").on("submit", function(e) {
                e.preventDefault(); // Mencegah reload halaman

                var kategori = $("#kategori").val().trim();

                $.ajax({
                    url: "simpan_kategori.php",
                    method: "POST",
                    data: {
                        kategori: kategori
                    },
                    dataType: "json",
                    success: function(response) {
                        var alertMsg = $("#alertMsg");
                        if (response.status === 'success') {
                            alertMsg.html(`<div class="alert alert-success">${response.message}</div>`);
                            $("#kategori").val('');
                            loadKategori();
                        } else {
                            alertMsg.html(`<div class="alert alert-danger">${response.message}</div>`);
                        }

                        setTimeout(function() {
                            alertMsg.empty();
                        }, 2000);
                    },
                });
            });

            $("#searchKategori").on("input", function() {
                var search = $(this).val().trim();
                loadKategori(search);
            });

            $("#searchBtn").on("click", function() {
                $("#searchKategori").val('');
            });
        });
    </script>
</body>

</html>