<?php
require 'session.php';
include('../koneksi.php'); // Koneksi ke database

$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Query untuk mengambil data pesanan dari tabel `pesanan`
$query = "SELECT 
            id AS no, 
            order_id, 
            nama AS customer_name, 
            alamat, 
            no_hp,  
            status_bayar,
            status_pesanan, 
            created_at 
          FROM pesanan";

// Jika ada pencarian, tambahkan kondisi
if (!empty($search)) {
    $query .= " WHERE nama LIKE '%$search%' 
                OR order_id LIKE '%$search%'
                OR alamat LIKE '%$search%'
                OR no_hp LIKE '%$search%'
                OR status_bayar LIKE '%$search%'
                OR status_pesanan LIKE '%$search%'
                OR created_at LIKE '%$search%'";
}

// Urutkan berdasarkan tanggal terbaru di atas (descending order)
$query .= " ORDER BY created_at DESC";

$result = mysqli_query($conn, $query);

$data = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
}

// Kirim data sebagai JSON
header('Content-Type: application/json');
echo json_encode($data);
