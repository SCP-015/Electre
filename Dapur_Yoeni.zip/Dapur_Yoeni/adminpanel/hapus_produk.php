<?php
require 'session.php';
require '../koneksi.php';

if (isset($_GET['p'])) {
    $id = intval($_GET['p']);

    // Mengambil data produk untuk menghapus gambar dari direktori
    $query = mysqli_query($conn, "SELECT * FROM produk WHERE id='$id'");

    if (mysqli_num_rows($query) > 0) {
        $data = mysqli_fetch_array($query);
        $gambar = $data['gambar'];

        // Menghapus gambar produk dari folder uploads jika ada
        if ($gambar && file_exists("../uploads/$gambar")) {
            unlink("../uploads/$gambar");
        }

        // Menghapus data produk dari database
        $deleteQuery = mysqli_query($conn, "DELETE FROM produk WHERE id='$id'");

        if ($deleteQuery) {
            header("Location: produk.php");
            exit();
        } else {
            echo "<script>alert('Gagal menghapus produk!'); window.location.href='produk.php';</script>";
        }
    } else {
        header("Location: produk.php");
        exit();
    }
} else {
    header("Location: produk.php");
    exit();
}
