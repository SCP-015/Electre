<?php
require 'session.php';
require '../koneksi.php';
header('Content-Type: application/json');

$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

$query = "SELECT produk.*, kategori.nama as kategori_nama FROM produk LEFT JOIN kategori ON produk.kategori_id = kategori.id";

if ($search) {
    $query .= " WHERE produk.nama LIKE '$search%' ORDER BY produk.nama ASC";
} else {
    $query .= " ORDER BY produk.nama ASC";
}

$queryProduk = mysqli_query($conn, $query);
$produkData = [];

if (mysqli_num_rows($queryProduk) > 0) {
    while ($data = mysqli_fetch_array($queryProduk)) {
        $produkData[] = [
            "id" => $data['id'],
            "kategori_nama" => $data['kategori_nama'],
            "nama" => $data['nama'],
            "harga" => $data['harga'],
            "detail" => $data['detail'],
            "gambar" => $data['gambar'] ? "../uploads/" . $data['gambar'] : null // tambahkan path gambar
        ];
    }
}

echo json_encode($produkData);
