<?php require 'session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.min.css">
    <title>Produk</title>
</head>

<style>
    .no-decoration {
        text-decoration: none;
    }
</style>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="home">DaYoen Adminpanel</a>
            <!-- Button to toggle navbar on mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link me-4" href="home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="kategori">Kategori</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="pesanan">Pesanan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="logout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="../adminpanel" class="no-decoration text-muted">
                        <i class="fas fa-home"></i> Home
                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    Produk
                </li>
            </ol>
        </nav>

        <div class="my-4 col-12 col-md-6">
            <h3>Tambah Produk</h3>
            <form id="produkForm" enctype="multipart/form-data">
                <div class="mt-2">
                    <select id="kategori_id" name="kategori_id" class="form-control" required>
                        <option value="">Pilih Kategori</option>
                        <?php
                        require '../koneksi.php';
                        $query = "SELECT * FROM kategori";
                        $result = mysqli_query($conn, $query);
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<option value='{$row['id']}'>{$row['nama']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="mt-2">
                    <input type="text" id="nama" name="nama" class="form-control" placeholder="Nama Produk" required>
                </div>
                <div class="mt-2">
                    <input type="number" id="harga" name="harga" class="form-control" placeholder="Harga" required>
                </div>
                <div class="mt-2">
                    <input type="file" id="gambar" name="gambar" class="form-control" required>
                </div>
                <div class="mt-2">
                    <textarea id="detail" name="detail" class="form-control" placeholder="Detail Produk" required></textarea>
                </div>
                <div class="mt-2">
                    <button class="btn btn-primary" type="submit">Simpan</button>
                </div>
            </form>
            <div id="alertMsg" class="mt-3"></div>
        </div>

        <div class="mt-4 d-flex justify-content-between align-items-center">
            <h2>Daftar Produk</h2>
            <div class="input-group" style="width: 300px;">
                <input type="text" id="searchProduk" class="form-control" placeholder="Cari produk...">
                <button class="btn btn-outline-secondary" id="searchBtn" type="button">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
        <div class="table-responsive mt-3">
            <table class="table table-bordered" style="table-layout: fixed; width: 100%;">
                <thead class="table-light text-center">
                    <tr>
                        <th class="text-center" style="width: 5%;">No.</th>
                        <th style="width: 15%;">Kategori</th>
                        <th style="width: 20%;">Nama Produk</th>
                        <th style="width: 15%;">Harga</th>
                        <th style="width: 40%;">Detail</th>
                        <th style="width: 15%;">Gambar</th>
                        <th class="text-center" style="width: 10%;">Aksi</th>
                    </tr>
                </thead>
                <tbody id="produkTable" class="table-striped">
                </tbody>
            </table>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Aktifkan tooltip di halaman
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });

            loadProduk();

            function loadProduk(search = "") {
                $.ajax({
                    url: "load_produk.php",
                    method: "GET",
                    data: {
                        search: search
                    },
                    dataType: "json",
                    success: function(data) {
                        var produkTable = $("#produkTable");
                        produkTable.empty();

                        if (data.length === 0) {
                            produkTable.append('<tr><td colspan="8" class="text-center">Tidak ada data Produk</td></tr>');
                        } else {
                            data.forEach(function(item, index) {
                                var row = `
                                        <tr>
                                            <td class="text-center">${index + 1}</td>
                                            <td>${item.kategori_nama}</td>
                                            <td>${item.nama}</td>
                                            <td>${item.harga}</td>
                                            <td>${item.detail}</td>
                                            <td class="text-center">
                                                ${item.gambar ? `<img src="${item.gambar}" alt="Gambar Produk" style="width: 50px; height: 50px; object-fit: cover;">` : 'Tidak ada gambar'}
                                            </td>
                                            <td class="text-center">
                                                <a href="edit_produk?p=${item.id}" class="btn btn-success btn-sm" data-bs-toggle="tooltip" title="Edit">
                                                    <i class="fas fa-pen"></i>
                                                </a>
                                                <a href="hapus_produk?p=${item.id}" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?');">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    `;
                                produkTable.append(row);
                            });
                        }
                    }
                });
            }

            $("#produkForm").on("submit", function(e) {
                e.preventDefault(); // Mencegah reload halaman

                var formData = new FormData(this);

                $.ajax({
                    url: "simpan_produk.php",
                    method: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    success: function(response) {
                        var alertMsg = $("#alertMsg");
                        if (response.status === 'success') {
                            alertMsg.html(`<div class="alert alert-success">${response.message}</div>`);
                            $("#produkForm")[0].reset();
                            loadProduk();
                        } else {
                            alertMsg.html(`<div class="alert alert-danger">${response.message}</div>`);
                        }

                        setTimeout(function() {
                            alertMsg.empty();
                        }, 2000);
                    },
                });
            });

            $("#searchProduk").on("input", function() {
                var search = $(this).val().trim();
                loadProduk(search);
            });

            $("#searchBtn").on("click", function() {
                $("#searchProduk").val('');
                loadProduk();
            });

        });
    </script>
</body>

</html>