<?php
require 'session.php';
require '../koneksi.php';

if (isset($_GET['p'])) {
    $id = intval($_GET['p']);
    // Cek apakah kategori masih digunakan oleh produk
    $queryCheck = mysqli_query($conn, "SELECT * FROM produk WHERE kategori_id='$id'");

    if (mysqli_num_rows($queryCheck) > 0) {
        // Jika kategori masih dipakai oleh produk, tampilkan alert dan redirect
        echo "<script>
                alert('Kategori ini masih digunakan oleh produk. Anda tidak dapat menghapusnya.');
                window.location.href = 'kategori.php';
              </script>";
        exit();
    } else {
        // Jika kategori tidak dipakai, lanjutkan penghapusan
        $query = mysqli_query($conn, "SELECT * FROM kategori WHERE id='$id'");

        if (mysqli_num_rows($query) > 0) {
            $deleteQuery = mysqli_query($conn, "DELETE FROM kategori WHERE id='$id'");
            if ($deleteQuery) {
                header("Location: kategori.php");
                exit();
            } else {
                header("Location: kategori.php");
                exit();
            }
        } else {
            header("Location: kategori.php");
            exit();
        }
    }
} else {
    header("Location: kategori.php");
    exit();
}
