<?php
require 'session.php';
require '../koneksi.php';

$id = $_GET['p'];

// Mengambil data produk berdasarkan ID
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id='$id'");
$data = mysqli_fetch_array($query);

if (!$data) {
    echo 'Produk tidak ditemukan.';
    exit();
}

// Proses edit produk jika form disubmit
if (isset($_POST['editBtn'])) {
    $nama = htmlspecialchars($_POST['nama']);
    $kategori = $_POST['kategori'];
    $harga = $_POST['harga'];
    $detail = htmlspecialchars($_POST['detail']);
    $gambar = $_FILES['gambar']['name'];
    $targetDir = "../uploads/";

    // Validasi gambar baru jika ada
    if ($gambar) {
        $targetFile = $targetDir . basename($gambar);
        move_uploaded_file($_FILES['gambar']['tmp_name'], $targetFile);
    } else {
        $gambar = $data['gambar'];  // Tetap gunakan gambar lama
    }

    // Update produk termasuk stok
    $updateQuery = mysqli_query($conn, "UPDATE produk SET nama='$nama', kategori_id='$kategori', harga='$harga', detail='$detail', gambar='$gambar' WHERE id='$id'");

    if ($updateQuery) {
        header("Location: produk");
        exit(); // Pastikan script berhenti setelah header di-set
    } else {
        echo '<div class="alert alert-danger mt-3">Gagal menyimpan perubahan.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <title>Edit Produk</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            width: 400px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #007bff;
            color: white;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .btn-primary {
            width: 100%;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="home">DaYoen Adminpanel</a>
            <!-- Button to toggle navbar on mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link me-4" href="home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="kategori">Kategori</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="pesanan">Pesanan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="logout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="card">
            <div class="card-header text-center">
                <h2 class="mb-0">Edit Produk</h2>
            </div>
            <div class="card-body">
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="nama">Nama Produk</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="<?php echo htmlspecialchars($data['nama']); ?>" required>
                    </div>
                    <div class="form-group mt-3">
                        <label for="kategori">Kategori</label>
                        <select name="kategori" id="kategori" class="form-control" required>
                            <?php
                            // Mengambil data kategori untuk dropdown
                            $kategoriQuery = mysqli_query($conn, "SELECT * FROM kategori");
                            while ($kategori = mysqli_fetch_array($kategoriQuery)) {
                                echo '<option value="' . $kategori['id'] . '"' . ($kategori['id'] == $data['kategori_id'] ? ' selected' : '') . '>' . htmlspecialchars($kategori['nama']) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group mt-3">
                        <label for="harga">Harga</label>
                        <input type="number" name="harga" id="harga" class="form-control" value="<?php echo htmlspecialchars($data['harga']); ?>" required>
                    </div>
                    <div class="form-group mt-3">
                        <label for="detail">Detail Produk</label>
                        <textarea name="detail" id="detail" class="form-control" required><?php echo htmlspecialchars($data['detail']); ?></textarea>
                    </div>
                    <div class="form-group mt-3">
                        <label for="gambar">Gambar Produk (Opsional)</label>
                        <input type="file" name="gambar" id="gambar" class="form-control">
                        <p class="text-muted">Gambar saat ini: <?php echo htmlspecialchars($data['gambar']); ?></p>
                    </div>
                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-primary" name="editBtn">Simpan</button>
                        <a href="produk" class="btn btn-danger">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>