<?php
require 'session.php';
require '../koneksi.php';

$id = $_GET['p'];

$query = mysqli_query($conn, "SELECT * FROM kategori WHERE id='$id'");
$data = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <title>Edit Kategori</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            width: 400px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #007bff;
            color: white;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .btn-primary {
            width: 100%;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="home">DaYoen Adminpanel</a>
            <!-- Button to toggle navbar on mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link me-4" href="home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="kategori">Kategori</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="pesanan">Pesanan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="logout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="card">
            <div class="card-header text-center">
                <h2 class="mb-0">Edit Kategori</h2>
            </div>
            <div class="card-body">
                <form action="" method="post">
                    <div class="form-group">
                        <label for="kategori">Nama Kategori</label>
                        <input type="text" name="kategori" id="kategori" class="form-control" value="<?php echo htmlspecialchars($data['nama']); ?>" required>
                    </div>
                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-primary" name="editBtn">Simpan</button>
                        <a href="kategori" class="btn btn-danger">Batal</a>
                    </div>
                </form>

                <?php
                if (isset($_POST['editBtn'])) {
                    $kategori = htmlspecialchars($_POST['kategori']);
                    $checkQuery = mysqli_query($conn, "SELECT * FROM kategori WHERE nama='$kategori' AND id != '$id'");

                    if (mysqli_num_rows($checkQuery) > 0) {
                        echo '<div class="alert alert-danger mt-3">Kategori "' . htmlspecialchars($kategori) . '" sudah ada!</div>';
                    } else {
                        $updateQuery = mysqli_query($conn, "UPDATE kategori SET nama='$kategori' WHERE id='$id'");

                        if ($updateQuery) {
                            header("Location: kategori");
                            exit();
                        }
                    }
                }
                ?>
            </div>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>