<?php
require 'session.php';
require '../koneksi.php';
header('Content-Type: application/json');

$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

$query = "SELECT * FROM kategori";

if ($search) {
    $query .= " WHERE nama LIKE '$search%' ORDER BY nama ASC";
} else {
    $query .= " ORDER BY nama ASC";
}

$queryKategori = mysqli_query($conn, $query);
$kategoriData = [];

if (mysqli_num_rows($queryKategori) > 0) {
    while ($data = mysqli_fetch_array($queryKategori)) {
        $kategoriData[] = [
            "id" => $data['id'],
            "nama" => $data['nama']
        ];
    }
}

echo json_encode($kategoriData);
