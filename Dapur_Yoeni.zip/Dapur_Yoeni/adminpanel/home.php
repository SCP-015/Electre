<?php
require 'session.php';
require '../koneksi.php';

// Query kategori
$queryKategori = mysqli_query($conn, "SELECT * FROM kategori");
$jumlahKategori = mysqli_num_rows($queryKategori);

// Query produk
$queryProduk = mysqli_query($conn, "SELECT * FROM produk");
$jumlahProduk = mysqli_num_rows($queryProduk);

// Query pesanan pending
$queryPesananPending = mysqli_query($conn, "SELECT COUNT(*) AS jumlahPending FROM pesanan WHERE status_pesanan = 'Pending'");
$jumlahPesananPending = mysqli_fetch_assoc($queryPesananPending)['jumlahPending'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.min.css">
    <style>
        .kotak {
            border: solid;
        }

        .summary-kategori,
        .summary-produk,
        .summary-pesanan {
            border-radius: 15px;
            padding: 20px;
            color: white;
        }

        .summary-kategori {
            background-color: #0a6b4a;
        }

        .summary-produk {
            background-color: #0a516b;
        }

        .summary-pesanan {
            background-color: #6b0a0a;
        }

        .no-decoration {
            text-decoration: none;
            color: white;
        }

        /* Responsif untuk perangkat mobile */
        @media (max-width: 768px) {

            .summary-kategori,
            .summary-produk,
            .summary-pesanan {
                padding: 15px;
            }

            .summary-kategori i,
            .summary-produk i,
            .summary-pesanan i {
                font-size: 4rem;
            }

            .summary-kategori h3,
            .summary-produk h3,
            .summary-pesanan h3 {
                font-size: 1.5rem;
            }

            .summary-kategori p,
            .summary-produk p,
            .summary-pesanan p {
                font-size: 1rem;
            }

            .breadcrumb {
                font-size: 0.9rem;
            }

            h2 {
                font-size: 1.5rem;
            }

            .container mt-5 {
                padding-left: 10px;
                padding-right: 10px;
            }
        }

        /* Responsif untuk perangkat yang lebih kecil (mobile portrait) */
        @media (max-width: 480px) {

            .summary-kategori i,
            .summary-produk i,
            .summary-pesanan i {
                font-size: 3rem;
            }

            .summary-kategori h3,
            .summary-produk h3,
            .summary-pesanan h3 {
                font-size: 1.3rem;
            }

            .summary-kategori p,
            .summary-produk p,
            .summary-pesanan p {
                font-size: 0.9rem;
            }

            h2 {
                font-size: 1.3rem;
            }
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="home">DaYoen Adminpanel</a>
            <!-- Button to toggle navbar on mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link me-4" href="home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="kategori">Kategori</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="pesanan">Pesanan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="logout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <i class="fas fa-home"></i> Home
                </li>
            </ol>
        </nav>
        <h2>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
        <p>Selamat datang di halaman utama.</p>

        <div class="row mt-5">
            <div class="col-lg-4 col-md-6 col-12 mb-3">
                <div class="summary-kategori">
                    <div class="row">
                        <div class="col-6">
                            <i class="fas fa-list fa-7x text-black-50"></i>
                        </div>
                        <div class="col-6">
                            <h3 class="fs-2">Kategori</h3>
                            <p class="fs-5"><?php echo $jumlahKategori; ?> Kategori</p>
                            <p><a href="kategori" class="text-white no-decoration">Lihat Detail</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-12 mb-3">
                <div class="summary-produk">
                    <div class="row">
                        <div class="col-6">
                            <i class="fas fa-box fa-7x text-black-50"></i>
                        </div>
                        <div class="col-6">
                            <h3 class="fs-2">Produk</h3>
                            <p class="fs-5"><?php echo $jumlahProduk; ?> Produk</p>
                            <p><a href="produk" class="text-white no-decoration">Lihat Detail</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-12 mb-3">
                <div class="summary-pesanan">
                    <div class="row">
                        <div class="col-6">
                            <i class="fas fa-shopping-cart fa-7x text-black-50"></i>
                        </div>
                        <div class="col-6">
                            <h3 class="fs-2">Pesanan</h3>
                            <p class="fs-5"><?php echo $jumlahPesananPending; ?> Pending</p>
                            <p><a href="pesanan" class="text-white no-decoration">Lihat Detail</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>

</html>