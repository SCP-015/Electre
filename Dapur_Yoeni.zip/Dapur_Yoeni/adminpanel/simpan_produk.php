<?php
require '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kategori_id = mysqli_real_escape_string($conn, $_POST['kategori_id']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $detail = mysqli_real_escape_string($conn, $_POST['detail']);
    $gambar = $_FILES['gambar'];

    // Validasi input
    if (!empty($kategori_id) && !empty($nama) && !empty($harga) && !empty($detail) && !empty($gambar['name'])) {
        $uploadDir = '../uploads/';
        $uploadFile = $uploadDir . basename($gambar['name']);
        $imageFileType = strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));

        // Validasi file gambar
        if (in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
            if (move_uploaded_file($gambar['tmp_name'], $uploadFile)) {
                $gambarNama = $gambar['name'];
                $query = "INSERT INTO produk (kategori_id, nama, harga, detail, gambar) VALUES ('$kategori_id', '$nama', '$harga', '$detail', '$gambarNama')";

                if (mysqli_query($conn, $query)) {
                    echo json_encode(['status' => 'success', 'message' => 'Produk berhasil disimpan']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan produk']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Gagal mengunggah gambar']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Format gambar tidak valid (gunakan JPG, JPEG, PNG, atau GIF)']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Semua field harus diisi']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
