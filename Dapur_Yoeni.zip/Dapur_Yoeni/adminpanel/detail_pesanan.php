<?php require 'session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <title>Detail Pesanan</title>
    <style>
        .no-decoration {
            text-decoration: none;
        }

        .breadcrumb-item a {
            color: #6c757d;
        }

        .breadcrumb-item.active {
            color: #495057;
        }

        .breadcrumb {
            background-color: #f8f9fa;
        }

        .card-header {
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }

        .table th,
        .table td {
            vertical-align: middle;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card-body p {
            font-size: 1.1rem;
            margin: 7px 0;
            line-height: 1.3;
        }

        .card-header i {
            margin-right: 10px;
        }

        .btn-back {
            width: 100%;
            margin-top: 20px;
            padding: 12px;
            background-color: #6c757d;
            color: white;
            border-radius: 5px;
            font-size: 1rem;
        }

        .btn-back:hover {
            background-color: #5a6268;
        }

        .table {
            font-size: 1rem;
        }

        .table td,
        .table th {
            padding: 12px 15px;
        }
    </style>
</head>

<body>
    <?php
    require '../koneksi.php';

    // Ambil ID Pesanan dari URL
    $order_id = isset($_GET['p']) ? mysqli_real_escape_string($conn, $_GET['p']) : '';

    // Query untuk mendapatkan data pesanan
    $orderQuery = "SELECT order_id, nama, alamat, no_hp, status_bayar, status_pesanan FROM pesanan WHERE order_id = '$order_id'";
    $orderResult = mysqli_query($conn, $orderQuery);
    $orderData = mysqli_fetch_assoc($orderResult);

    // Query untuk mendapatkan detail produk
    $itemsQuery = "SELECT nama_produk, jumlah, harga, total FROM tabel_detail_pesanan WHERE order_id = '$order_id'";
    $itemsResult = mysqli_query($conn, $itemsQuery);

    // Proses tombol Lunas
    if (isset($_POST['update_status_bayar_paid'])) {
        $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
        $updateQuery = "UPDATE pesanan SET status_bayar = 'Lunas' WHERE order_id = '$order_id'";
        if (mysqli_query($conn, $updateQuery)) {
            header("Location: detail_pesanan?p=$order_id");
            exit;
        } else {
            echo "<div class='alert alert-danger'>Gagal mengubah status pesanan.</div>";
        }
    }

    // Proses tombol Sedang Diproses
    if (isset($_POST['update_status_pesanan_processed'])) {
        $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
        $updateQuery = "UPDATE pesanan SET status_pesanan = 'Sedang Diproses' WHERE order_id = '$order_id'";
        if (mysqli_query($conn, $updateQuery)) {
            header("Location: detail_pesanan?p=$order_id");
            exit;
        } else {
            echo "<div class='alert alert-danger'>Gagal mengubah status pesanan.</div>";
        }
    }

    // Proses tombol Dikirim
    if (isset($_POST['update_status_pesanan_shipped'])) {
        $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
        $updateQuery = "UPDATE pesanan SET status_pesanan = 'Dalam Pengiriman' WHERE order_id = '$order_id'";
        if (mysqli_query($conn, $updateQuery)) {
            header("Location: detail_pesanan?p=$order_id");
            exit;
        } else {
            echo "<div class='alert alert-danger'>Gagal mengubah status pesanan.</div>";
        }
    }

    // Proses tombol Selesai
    if (isset($_POST['update_status_pesanan_completed'])) {
        $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
        $updateQuery = "UPDATE pesanan SET status_pesanan = 'Selesai' WHERE order_id = '$order_id'";
        if (mysqli_query($conn, $updateQuery)) {
            header("Location: detail_pesanan?p=$order_id");
            exit;
        } else {
            echo "<div class='alert alert-danger'>Gagal mengubah status pesanan.</div>";
        }
    }

    // Proses tombol Cancel Pembayaran
    if (isset($_POST['update_status_bayar_cancel'])) {
        $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
        $updateQuery = "UPDATE pesanan SET status_pesanan = 'Dibatalkan' WHERE order_id = '$order_id'";
        if (mysqli_query($conn, $updateQuery)) {
            header("Location: detail_pesanan?p=$order_id");
            exit;
        } else {
            echo "<div class='alert alert-danger'>Gagal mengubah status pesanan.</div>";
        }
    }

    // Proses tombol Cancel Pengiriman
    if (isset($_POST['update_status_pesanan_cancel'])) {
        $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
        $updateQuery = "UPDATE pesanan SET status_pesanan = 'Dibatalkan' WHERE order_id = '$order_id'";
        if (mysqli_query($conn, $updateQuery)) {
            header("Location: detail_pesanan?p=$order_id");
            exit;
        } else {
            echo "<div class='alert alert-danger'>Gagal mengubah status pesanan.</div>";
        }
    }
    ?>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="home">DaYoen Adminpanel</a>
            <!-- Button to toggle navbar on mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link me-4" href="home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="kategori">Kategori</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="pesanan">Pesanan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-4" href="logout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index" class="no-decoration">
                        <i class="fas fa-home"></i> Home
                    </a>
                </li>
                <li class="breadcrumb-item">
                    <a href="pesanan" class="no-decoration">Pesanan</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Detail Pesanan</li>
            </ol>
        </nav>

        <h2 class="mb-4">Detail Pesanan</h2>

        <div class="card shadow-sm mb-4 mx-auto col-md-8 col-lg-6">
            <div class="card-header">
                <i class="fas fa-info-circle"></i> Informasi Pesanan
            </div>
            <div class="card-body">
                <p><strong>ID Pesanan:</strong> <?= htmlspecialchars($orderData['order_id']); ?></p>
                <p><strong>Nama Pembeli:</strong> <?= htmlspecialchars($orderData['nama']); ?></p>
                <p><strong>Alamat:</strong> <?= htmlspecialchars($orderData['alamat']); ?></p>
                <p><strong>No HP:</strong> <?= htmlspecialchars($orderData['no_hp']); ?></p>
                <p><strong>Status Pembayaran:</strong> <?= htmlspecialchars($orderData['status_bayar']); ?></p>
                <?php if ($orderData['status_bayar'] === 'Belum Bayar') : ?>
                    <form method="POST" action="">
                        <input type="hidden" name="order_id" value="<?= htmlspecialchars($orderData['order_id']); ?>">
                        <button type="submit" name="update_status_bayar_paid" class="btn btn-success">Lunas</button>
                    </form>
                <?php endif; ?>
                <?php if ($orderData['status_bayar'] === 'Belum Bayar') : ?>
                    <form method="POST" action="">
                        <input type="hidden" name="order_id" value="<?= htmlspecialchars($orderData['order_id']); ?>">
                        <button type="submit" name="update_status_bayar_cancel" class="btn btn-danger">Cancel</button>
                    </form>
                <?php endif; ?>
                <p><strong>Status Pengiriman:</strong> <?= htmlspecialchars($orderData['status_pesanan']); ?></p>

                <!-- Tombol berdasarkan status pesanan -->
                <?php if ($orderData['status_pesanan'] === 'Pending') : ?>
                    <form method="POST" action="">
                        <input type="hidden" name="order_id" value="<?= htmlspecialchars($orderData['order_id']); ?>">
                        <button type="submit" name="update_status_pesanan_processed" class="btn btn-success">Diproses</button>
                    </form>
                <?php elseif ($orderData['status_pesanan'] === 'Sedang Diproses') : ?>
                    <form method="POST" action="">
                        <input type="hidden" name="order_id" value="<?= htmlspecialchars($orderData['order_id']); ?>">
                        <button type="submit" name="update_status_pesanan_shipped" class="btn btn-primary">Dikirim</button>
                    </form>
                <?php elseif ($orderData['status_pesanan'] === 'Dalam Pengiriman') : ?>
                    <form method="POST" action="">
                        <input type="hidden" name="order_id" value="<?= htmlspecialchars($orderData['order_id']); ?>">
                        <button type="submit" name="update_status_pesanan_completed" class="btn btn-success">Selesai</button>
                    </form>
                <?php endif; ?>

                <!-- Tombol Batal (akan hilang jika status pesanan adalah Selesai) -->
                <?php if ($orderData['status_pesanan'] !== 'Selesai') : ?>
                    <form method="POST" action="">
                        <input type="hidden" name="order_id" value="<?= htmlspecialchars($orderData['order_id']); ?>">
                        <button type="submit" name="update_status_pesanan_cancel" class="btn btn-danger">Batal</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <h4 class="mt-4">Produk yang Dipesan</h4>

        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th class="text-center">No.</th>
                        <th>Nama Produk</th>
                        <th class="text-center">Jumlah</th>
                        <th class="text-center">Harga Satuan</th>
                        <th class="text-center">Total Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    while ($item = mysqli_fetch_assoc($itemsResult)) {
                    ?>
                        <tr>
                            <td class="text-center"><?= $no++; ?></td>
                            <td><?= htmlspecialchars($item['nama_produk']); ?></td>
                            <td class="text-center"><?= $item['jumlah']; ?></td>
                            <td class="text-center">Rp <?= number_format($item['harga'], 0, ',', '.'); ?></td>
                            <td class="text-center">Rp <?= number_format($item['total'], 0, ',', '.'); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <a href="pesanan" class="btn-back">Kembali</a>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>

</html>