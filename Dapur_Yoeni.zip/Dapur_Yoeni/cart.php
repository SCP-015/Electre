<?php
session_start();
include_once 'koneksi.php'; // Koneksi ke database

// Menghitung total harga dari semua produk dalam keranjang
function calculateTotalPrice()
{
    $totalPrice = 0;
    foreach ($_SESSION['cart'] as $item) {
        $totalPrice += $item['quantity'] * $item['price'];
    }
    return $totalPrice;
}

// Perbarui keranjang jika ada perubahan quantity
if (isset($_POST['update_cart'])) {
    // Update kuantitas setiap produk dalam keranjang
    foreach ($_SESSION['cart'] as $productId => &$item) {
        if (isset($_POST['quantity'][$productId])) {
            $newQuantity = (int)$_POST['quantity'][$productId];
            // Jika kuantitas diubah menjadi 0, hapus produk tersebut
            if ($newQuantity === 0) {
                unset($_SESSION['cart'][$productId]);
            } else {
                $item['quantity'] = $newQuantity;
            }
        }
    }

    // Hapus flag perubahan kuantitas setelah update
    unset($_SESSION['cart_modified']);

    // Redirect kembali ke halaman keranjang setelah update
    header('Location: cart');
    exit();
}

// Set flag perubahan kuantitas jika ada perubahan yang belum diupdate
if (isset($_POST['quantity']) && !isset($_POST['update_cart'])) {
    $_SESSION['cart_modified'] = true;
}

// Hapus produk dari keranjang jika tombol hapus ditekan
if (isset($_GET['delete'])) {
    $productIdToDelete = $_GET['delete'];
    if (isset($_SESSION['cart'][$productIdToDelete])) {
        unset($_SESSION['cart'][$productIdToDelete]);
    }
    // Redirect kembali ke halaman keranjang setelah penghapusan
    header('Location: cart.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #ffeeb2;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            /* Menghapus margin default */
            padding: 0 15px;
            /* Memberikan padding kiri dan kanan 15px agar konten tidak menempel ke sisi body */
            box-sizing: border-box;
            /* Agar padding dihitung dalam ukuran total body */
        }

        .container {
            background-color: #fff;
            border-radius: 15px;
            padding: 30px 40px;
            /* Padding lebih besar di atas, bawah, kiri, dan kanan */
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            margin: 30px auto;
            /* Margin atas dan bawah 30px, dan auto untuk kiri dan kanan agar terpusat */
            max-width: 1200px;
            /* Maksimal lebar kontainer 1200px untuk tampilan lebih besar */
            width: 100%;
            /* Agar kontainer bisa menyesuaikan lebar perangkat */
            box-sizing: border-box;
            /* Menghitung padding dan border dalam lebar total */
        }

        h1 {
            font-family: 'Poppins', sans-serif;
            color: #f39c12;
            margin-bottom: 30px;
            text-align: center;
        }

        table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
        }

        table th,
        table td {
            padding: 12px;
            text-align: center;
            vertical-align: middle;
        }

        table th:nth-child(1),
        table td:nth-child(1) {
            width: 5%;
        }

        table th:nth-child(2),
        table td:nth-child(2) {
            width: 40%;
        }

        table th:nth-child(3),
        table td:nth-child(3) {
            width: 15%;
        }

        table th:nth-child(4),
        table td:nth-child(4) {
            width: 15%;
        }

        table th:nth-child(5),
        table td:nth-child(5) {
            width: 20%;
        }

        table th:nth-child(6),
        table td:nth-child(6) {
            width: 10%;
        }

        table thead {
            background-color: #f39c12;
            color: white;
            font-size: 1.1rem;
        }

        table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .total-price {
            font-size: 1.6rem;
            font-weight: 700;
            color: #f39c12;
            margin-top: 20px;
        }

        .btn-success {
            background-color: #f39c12;
            border-color: #f39c12;
            padding: 12px 25px;
            font-size: 1.1rem;
            border-radius: 8px;
            transition: background-color 0.3s ease;
            text-transform: uppercase;
        }

        .btn-success:hover {
            background-color: #e67e22;
            border-color: #e67e22;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
            padding: 12px 25px;
            font-size: 1.1rem;
            border-radius: 8px;
            text-transform: uppercase;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }

        .empty-cart-message {
            font-size: 1.3rem;
            color: #f39c12;
            text-align: center;
            margin-top: 50px;
        }

        .form-control {
            width: 70px;
            height: 35px;
            font-size: 1rem;
            margin: 0 auto;
        }

        .cart-table .fa-trash-alt {
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0 5px;
            transition: color 0.3s ease;
        }

        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        /* Responsif untuk layar dengan lebar maksimal 768px */
        @media (max-width: 768px) {
            body {
                padding: 0 10px;
                /* Mengurangi padding body agar tetap ada jarak namun tidak terlalu banyak */
            }

            .container {
                padding: 20px;
                /* Padding lebih seimbang di kiri dan kanan */
                margin: 20px;
                /* Margin kiri-kanan lebih kecil */
            }

            table th,
            table td {
                font-size: 0.9rem;
                padding: 8px;
            }

            .form-control {
                width: 50px;
            }

            .total-price {
                font-size: 1.4rem;
            }

            .btn-success,
            .btn-secondary {
                padding: 10px 20px;
                font-size: 1rem;
            }

            h1 {
                font-size: 1.5rem;
            }

            .d-flex {
                flex-direction: column;
                gap: 10px;
            }

            .table-responsive {
                padding-bottom: 20px;
            }

            .btn-success:disabled {
                opacity: 0.5;
            }
        }

        /* Responsif untuk layar lebih kecil dari 576px */
        @media (max-width: 576px) {
            body {
                padding: 0 5px;
                /* Padding lebih kecil untuk layar sangat kecil */
            }

            .container {
                padding: 15px;
                /* Padding lebih kecil lagi pada layar sangat kecil */
                margin: 10px;
                /* Margin kiri-kanan lebih kecil */
            }

            h1 {
                font-size: 1.2rem;
            }

            table th,
            table td {
                font-size: 0.8rem;
                padding: 6px;
            }

            .form-control {
                width: 40px;
            }

            .btn-success,
            .btn-secondary {
                padding: 8px 15px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>

<body>
    <div class="container py-5">
        <h1>Keranjang Belanja</h1>

        <?php if (empty($_SESSION['cart'])): ?>
            <p class="empty-cart-message">Keranjang Anda kosong.</p>
            <div class="d-flex justify-content-center">
                <a href="produk" class="btn btn-secondary">Lanjut Belanja</a>
            </div>
        <?php else: ?>
            <form method="POST" action="cart.php">
                <div class="table-responsive">
                    <table class="table table-hover cart-table align-middle">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Produk</th>
                                <th>Kuantitas</th>
                                <th>Harga</th>
                                <th>Subtotal</th>
                                <th>Aksi</th> <!-- Kolom Aksi -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $totalPrice = calculateTotalPrice();
                            $index = 1;
                            foreach ($_SESSION['cart'] as $productId => $item):
                                $subtotal = $item['quantity'] * $item['price'];
                            ?>
                                <tr>
                                    <td><?= $index++ ?></td> <!-- Nomor urut -->
                                    <td><?= htmlspecialchars($item['name']) ?></td>
                                    <td>
                                        <input type="number" class="form-control" name="quantity[<?= $productId ?>]" value="<?= $item['quantity'] ?>" min="0" max="999">
                                    </td>
                                    <td>Rp <?= number_format($item['price'], 0, ',', '.') ?></td>
                                    <td>Rp <?= number_format($subtotal, 0, ',', '.') ?></td>
                                    <td>
                                        <a href="cart.php?delete=<?= $productId ?>" class="btn btn-danger" title="Hapus Produk">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="d-flex justify-content-end">
                    <h4 class="total-price">Total: Rp <?= number_format($totalPrice, 0, ',', '.') ?></h4>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="produk" class="btn btn-secondary">Kembali</a>
                    <div class="ms-2">
                        <button type="submit" name="update_cart" class="btn btn-success">Update Cart</button>
                        <a href="checkout" class="btn btn-success ms-2"
                            <?php if (isset($_SESSION['cart_modified'])): ?> disabled <?php endif; ?>>Checkout</a>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
    <?php $conn->close(); ?>
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>