<?php session_start() ?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dapur Yoeni | Sirup Lemon Berkualitas</title>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;600&display=swap" rel="stylesheet">
    <!-- Link ke CSS Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Link ke Animasi AOS (Animate on Scroll) -->
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">

    <!-- Kustom CSS -->
    <style>
        html,
        body {
            overflow-x: hidden;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: #fff;
        }

        .navbar {
            position: fixed;
            top: 0;
            z-index: 1000;
            width: 100%;
            background: linear-gradient(135deg, #f39c12, #f39c12);
            backdrop-filter: blur(10px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease-in-out;
        }

        .navbar:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .navbar .navbar-brand {
            color: #fff;
        }

        .navbar .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.1rem;
        }

        .navbar .navbar-nav .nav-link:hover {
            color: #ffe499 !important;
        }

        .cart-icon-wrapper {
            position: relative;
            cursor: pointer;
        }

        .cart-icon {
            font-size: 2rem;
            color: #fff;
        }

        .cart-badge {
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: #dc3545;
            color: white;
            border-radius: 50%;
            padding: 5px 10px;
            font-size: 0.8rem;
        }

        /* Hero Section */
        #hero {
            height: 100vh;
            background-image: url('image/carousel1.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            text-align: center;
            position: relative;
        }

        #hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }

        #hero .content {
            z-index: 10;
            opacity: 0;
            animation: fadeIn 2s forwards;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        #hero h1 {
            font-size: 4rem;
            font-family: "Montserrat", serif;
            font-weight: bold;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.7);
            margin-bottom: 20px;
        }

        #hero p {
            font-size: 1.5rem;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            color: #f1f2f6;
            margin-bottom: 20px;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.5);
        }

        #hero .btn-primary {
            background-color: #f39c12;
            border: none;
            padding: 12px 25px;
            font-size: 1.25rem;
            border-radius: 7px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
            color: white;
            text-align: center;
            transition: transform 0.4s ease;
        }

        #hero .btn-primary::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background-color: #e67e22;
            transition: left 0.4s ease;
            z-index: -1;
        }

        #hero .btn-primary:hover {
            transform: scale(1);
        }

        #hero .btn-primary:hover::before {
            left: 0;
        }

        #founder {
            padding: 60px 0;
            background-color: #f8f9fa;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            /* Background yang lebih cerah */
        }

        #founder h2 {
            text-align: center;
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 40px;
            color: #333;
        }

        .founder-image {
            text-align: center;
            /* Memastikan gambar berada di tengah */
        }

        .founder-image img {
            max-width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            /* Membuat gambar menjadi lingkaran */
            border: 5px solid #fff;
            /* Tambahan border putih di sekitar gambar */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            /* Memberikan efek bayangan */
        }

        .founder-description p {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
            text-align: justify;
            font-family: 'Arial', sans-serif;
        }

        /* Semua ukuran layar */
        .col-12 {
            margin-bottom: 20px;
            /* Memberikan jarak antar elemen */
        }

        /* Responsif untuk layar kecil */
        @media (max-width: 1199px) {
            #founder h2 {
                font-size: 2rem;
            }

            .founder-description p {
                font-size: 1.05rem;
            }
        }

        @media (max-width: 991px) {
            .founder-image img {
                max-width: 130px;
                height: 130px;
            }

            #founder h2 {
                font-size: 2rem;
            }
        }

        @media (max-width: 767px) {
            .founder-image img {
                max-width: 120px;
                height: 120px;
            }

            #founder h2 {
                font-size: 2rem;
            }

            .founder-description p {
                font-size: 1rem;
            }
        }

        @media (max-width: 576px) {
            #founder h2 {
                font-size: 2rem;
            }

            .founder-description p {
                font-size: 0.95rem;
            }

            .founder-image img {
                max-width: 110px;
                height: 110px;
            }
        }

        /* Tentang Kami */
        #tentang-kami {
            background-color: #f2f3f4;
            height: auto;
            padding: 50px 20px;
            display: flex;
            justify-content: center;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            flex-direction: column;
            /* Menyusun konten secara vertikal pada semua ukuran layar */
        }

        #tentang-kami h2 {
            font-size: 4rem;
            margin-bottom: 80px;
            text-align: center;
        }

        #tentang-kami p {
            font-size: 20px;
            text-align: justify;
        }

        #tentang-kami .col-md-5,
        #tentang-kami .col-md-6 {
            padding: 0 20px;
            box-sizing: border-box;
        }

        /* Responsif untuk perangkat mobile */
        @media (max-width: 767px) {
            #tentang-kami {
                padding: 30px 15px;
                /* Mengurangi padding untuk layar kecil */
            }

            #tentang-kami h2 {
                font-size: 2.5rem;
                /* Mengurangi ukuran font pada judul di mobile */
                margin-bottom: 40px;
                /* Menyesuaikan jarak antara judul dan konten */
            }

            #tentang-kami p {
                font-size: 16px;
                /* Mengurangi ukuran font pada deskripsi di mobile */
            }

            /* Menambahkan margin-bottom pada gambar agar ada jarak antara gambar dan deskripsi */
            #tentang-kami .col-md-5 {
                margin-bottom: 20px;
                /* Jarak antara gambar dan deskripsi pada mobile */
            }
        }


        /* Produk Section */
        #produk {
            background-color: #feeeb2;
            height: auto;
            padding: 50px 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
            background: #fff;
            position: relative;
            height: 100%;
        }

        .card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-bottom: 5px solid #f39c12;
            border-radius: 10px;
            display: block;
            transition: transform 0.3s ease-in-out;
        }

        .card:hover img {
            transform: scale(1.05);
        }

        .card-body {
            padding: 30px 20px;
            border-radius: 10px;
            text-align: center;
            background-color: #fafafa;
        }

        .card-body h5 {
            font-size: 1.5rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
        }

        .card-body p {
            font-size: 1.125rem;
            color: #555;
            margin-bottom: 20px;
        }

        .card-body .btn {
            background-color: #f39c12;
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            border: none;
            font-size: 1.1rem;
            transition: background-color 0.3s ease-in-out, transform 0.3s ease-in-out;
        }

        .card-body .btn:hover {
            background-color: #e67e22;
            transform: translateY(-5px);
        }

        .col-md-4 {
            margin-bottom: 30px;
            flex: 1 1 30%;
            /* Flexbox for responsive grid */
        }

        #produk h2 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 60px;
        }

        /* Carousel Section */
        #carousel {
            height: auto;
            padding: 50px 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #feeeb2;
            z-index: 1;
        }

        .carousel-inner {
            width: 100%;
            overflow: hidden;
            border-radius: 15px;
        }

        .carousel-item img {
            height: 500px;
            width: 100%;
            object-fit: cover;
        }

        /* Keunggulan Produk */
        #keunggulan {
            background-color: #f9f9f9;
            min-height: 60vh;
            padding: 80px 0;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        #keunggulan h2 {
            font-size: 3rem;
            margin-bottom: 80px;
            font-weight: bold;
            color: #333;
        }

        #keunggulan .keunggulan-item {
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        #keunggulan .keunggulan-item i {
            font-size: 3rem;
            color: #f39c12;
            margin-bottom: 20px;
        }

        #keunggulan .keunggulan-item h4 {
            font-size: 1.8rem;
            font-weight: 600;
            margin-bottom: 15px;
        }

        #keunggulan .keunggulan-item p {
            font-size: 1.2rem;
            color: #666;
        }

        /* Testimoni */
        #testimoni {
            background-color: #f1f2f6;
            padding: 30px;
            display: flex;
            flex-direction: column;
            /* Susun vertikal: h2 di atas, testimoni di bawah */
            align-items: center;
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
            /* Center h2 */
            text-align: center;
        }

        #testimoni h2 {
            font-size: 2rem;
            margin-bottom: 30px;
            /* Memberikan jarak antara h2 dan testimonial */
            color: #333;
        }

        .testimoni-container {
            display: flex;
            justify-content: center;
            /* Testimonial berada di tengah */
            gap: 20px;
            /* Memberikan jarak antar card */
            flex-wrap: wrap;
            /* Membuat testimonial bisa membungkus di layar kecil */
        }

        .testimoni-item {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin: 10px;
            width: 300px;
            /* Lebar card yang tetap */
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .testimoni-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            /* Shadow saat hover */
        }

        .testimonial-photo {
            margin-bottom: 20px;
            /* Memberikan jarak foto dengan konten lain */
        }

        .testimonial-photo img {
            width: 90px;
            height: 90px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid #f39c12;
        }

        .rating {
            font-size: 18px;
            color: #f39c12;
            margin-bottom: 10px;
        }

        .star {
            margin-right: 5px;
            font-size: 20px;
        }

        h4 {
            font-weight: bold;
            margin-top: 15px;
        }

        .testimoni-item p {
            font-style: italic;
            margin-bottom: 15px;
            color: #555;
            /* Warna teks lebih gelap agar lebih kontras */
        }

        @media (max-width: 768px) {
            .testimoni-item {
                width: 100%;
                /* Membuat card penuh lebar pada layar kecil */
                margin-bottom: 30px;
                /* Jarak antar card */
            }
        }

        /* Footer */
        footer {
            background-color: #333;
            color: white;
            padding: 40px 0;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif
        }

        footer a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
        }

        footer a:hover {
            color: #f39c12;
        }

        @media (max-width: 768px) {
            .col-md-4 {
                flex: 1 1 100%;
                /* Full-width on smaller screens */
            }

            #hero h1 {
                font-size: 2.5rem;
            }

            #hero p {
                font-size: 1.2rem;
            }

            #produk .card {
                width: 100%;
            }

            .navbar-nav {
                text-align: center;
            }

            .cart-icon-wrapper {
                margin-top: 10px;
            }

            footer {
                text-align: left;
            }
        }
    </style>

</head>

<body>
    <!-- JavaScript untuk kontrol animasi dan AOS -->
    <script>
        window.addEventListener('load', function() {
            // Pastikan navbar mendapatkan kelas initial-load saat pertama kali dimuat
            var navbar = document.querySelector('.navbar');
            navbar.classList.add('initial-load'); // Menambahkan kelas initial-load

            AOS.init(); // Menginisialisasi AOS

            // Inisialisasi carousel Bootstrap
            var myCarousel = document.getElementById('productCarousel');
            var carousel = new bootstrap.Carousel(myCarousel, {
                interval: 3000,
                ride: 'carousel'
            });
        });
    </script>
    <nav class="navbar navbar-expand-lg navbar-light initial-load" data-aos="slide-down" data-aos-duration="1000" data-aos-easing="ease-in-out">
        <div class="container-fluid">
            <!-- Logo on the left -->
            <a class="navbar-brand" href="home">
                <img src="image/yoeni.png" alt="Logo" style="height: 40px; width: auto;">
            </a>

            <!-- Navbar links on the right -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="produk">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="galeri">Galeri</a>
                    </li>
                </ul>
                <div class="cart-icon-wrapper" onclick="window.location.href='cart';">
                    <i class="fas fa-shopping-cart cart-icon"></i>
                    <span class="cart-badge" id="total-products-badge">
                        <?php
                        // Menghitung jumlah produk unik di keranjang
                        $totalProducts = 0;
                        if (isset($_SESSION['cart'])) {
                            $totalProducts = count($_SESSION['cart']); // Hitung jumlah item unik di keranjang
                        }
                        echo $totalProducts;
                        ?>
                    </span>
                </div>
            </div>
        </div>
    </nav>


    <!-- Hero Section -->
    <section id="hero" data-aos="fade-in" data-aos-duration="2000">
        <div class="content" data-aos="slide-up" data-aos-duration="2500">
            <h1>Sirup Alami Berkualitas</h1>
            <p>Rasakan kesegaran dan manfaat alami dalam setiap tetesnya</p>
            <a href="produk" class="btn btn-primary btn-lg">Beli Sekarang</a>
        </div>
    </section>

    <!-- Carousel Section -->
    <section id="carousel" data-aos="fade-in" data-aos-duration="1000">
        <div class="container mt-5">
            <h3 class="text-center mb-4" style="font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif; font-weight:bold; font-size:3rem">Temukan Rasa Unik</h2> <!-- Judul -->
                <p class="text-center mb-4">Nikmati berbagai pilihan sirup alami terbaik dari Dapur Yoeni.</p> <!-- Keterangan -->
                <div id="productCarousel" class="carousel slide" data-aos="zoom-in" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="image/carousel1.jpg" class="d-block w-100" alt="Product 1">
                        </div>
                        <div class="carousel-item">
                            <img src="image/carousel1.jpg" class="d-block w-100" alt="Product 2">
                        </div>
                        <div class="carousel-item">
                            <img src="image/carousel1.jpg" class="d-block w-100" alt="Product 3">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#productCarousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
        </div>
    </section>

    <!-- Founder Section -->
    <section id="founder" data-aos="fade-up">
        <div class="container">
            <h2>Pendiri Usaha</h2>
            <div class="row justify-content-center">
                <!-- Foto Founder -->
                <div class="col-12 text-center">
                    <div class="founder-image">
                        <img src="image/sirup.jpg" alt="Foto Founder" class="img-fluid rounded-circle">
                    </div>
                </div>
                <!-- Deskripsi Founder -->
                <div class="col-12">
                    <div class="founder-description">
                        <p>Nama kami adalah [Nama Founder], pendiri [Nama UMKM]. Dengan visi untuk menyediakan produk berkualitas tinggi, kami memulai usaha ini dengan keyakinan bahwa setiap orang pantas menikmati produk yang sehat dan alami. Sebagai seorang pengusaha, kami berkomitmen untuk terus berkembang dan memberikan produk terbaik kepada pelanggan kami.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- Tentang Kami Section -->
    <section id="tentang-kami" data-aos="fade-left">
        <div class="container">
            <h2>Tentang Kami</h2>
            <div class="row justify-content-center">
                <!-- Kiri: Foto -->
                <div class="col-md-5">
                    <div class="about-image">
                        <img src="image/tentang.jpg" alt="Foto Perusahaan" class="img-fluid rounded">
                    </div>
                </div>
                <!-- Kanan: Deskripsi -->
                <div class="col-md-6">
                    <div class="about-description">
                        <p>Kami adalah pengusaha yang berkomitmen untuk menyediakan sirup alami berkualitas tinggi dengan bahan-bahan pilihan. Produk kami dibuat dengan penuh perhatian terhadap kualitas dan rasa, tanpa bahan pengawet atau pemanis buatan.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Produk Section -->
    <section id="produk" data-aos="fade-up">
        <div class="container">
            <h2 class="text-center mb-4" style="font-size: 3rem; font-family: Playfair Display, serif;">Produk Terlaris</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <img src="image/lemon1.jpg" alt="Sirup Lemon" class="d-block w-100">
                        <div class="card-body">
                            <h5>Sirup Lemon</h5>
                            <p>Segar dan alami, ideal untuk berbagai minuman yang menyegarkan.</p>
                            <a href="produk" class="btn btn-primary">Beli Sekarang</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card">
                        <img src="image/stikkeju.jpg" alt="Sirup Mangga" class="d-block w-100">
                        <div class="card-body">
                            <h5>Stik Keju</h5>
                            <p>Nikmati sensasi gurih yang memuaskan, cocok untuk menemani hari Anda.</p>
                            <a href="produk" class="btn btn-primary">Beli Sekarang</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card">
                        <img src="image/lemon3.jpg" alt="Sirup Nanas" class="d-block w-100">
                        <div class="card-body">
                            <h5>Jus Lemon</h5>
                            <p>Rasa tropis yang menyegarkan, sempurna untuk cuaca panas.</p>
                            <a href="produk" class="btn btn-primary">Beli Sekarang</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Keunggulan Produk -->
    <section id="keunggulan" data-aos="fade-right">
        <div class="container">
            <h2>Keunggulan Produk Kami</h2>
            <div class="row">
                <div class="col-md-4 keunggulan-item">
                    <i class="fas fa-leaf"></i>
                    <h4>100% Alami</h4>
                    <p>Terbuat dari bahan-bahan alami tanpa bahan pengawet dan pemanis buatan.</p>
                </div>
                <div class="col-md-4 keunggulan-item">
                    <i class="fas fa-medal"></i>
                    <h4>Kualitas Terjamin</h4>
                    <p>Diproduksi dengan teknologi terkini untuk menghasilkan produk terbaik.</p>
                </div>
                <div class="col-md-4 keunggulan-item">
                    <i class="fas fa-star"></i>
                    <h4>Rasa Unik</h4>
                    <p>Setiap rasa kami memiliki cita rasa otentik yang membuatnya berbeda.</p>
                </div>
            </div>
        </div>
    </section>


    <!-- Testimoni Section -->
    <section id="testimoni" data-aos="fade-up">
        <h2 style="font-size: 2rem;">Testimoni Pelanggan</h2>
        <div class="testimoni-container">
            <div class="testimoni-item">
                <div class="testimonial-photo">
                    <img src="image/testi1.jpeg" alt="Foto Pengguna">
                </div>
                <div class="rating">
                    <span class="star">★</span>
                    <span class="star">★</span>
                    <span class="star">★</span>
                    <span class="star">★</span>
                    <span class="star">☆</span>
                </div>
                <h4>Jane Smith</h4>
                <p>"Layanan yang luar biasa, sangat memuaskan!"</p>
            </div>

            <div class="testimoni-item">
                <div class="testimonial-photo">
                    <img src="image/testi2.jpeg" alt="Foto Pengguna">
                </div>
                <div class="rating">
                    <span class="star">★</span>
                    <span class="star">★</span>
                    <span class="star">★</span>
                    <span class="star">★</span>
                    <span class="star">★</span>
                </div>
                <h4>John Doe</h4>
                <p>"Produk yang sangat berkualitas, saya akan beli lagi!"</p>
            </div>

            <div class="testimoni-item">
                <div class="testimonial-photo">
                    <img src="image/testi3.jpeg" alt="Foto Pengguna">
                </div>
                <div class="rating">
                    <span class="star">★</span>
                    <span class="star">★</span>
                    <span class="star">★</span>
                    <span class="star">★</span>
                    <span class="star">☆</span>
                </div>
                <h4>Alice Cooper</h4>
                <p>"Pelayanan cepat dan ramah. Saya sangat puas!"</p>
            </div>
        </div>
    </section>


    <!-- Footer Section -->
    <footer>
        <div class="container">
            <div class="row">
                <!-- Logo and Description -->
                <div class="col-md-3">
                    <img src="image/yoeni.png" alt="UMKM Logo" style="width: 100px;">
                    <h5 style="margin-top: 15px;">Dapur Yoeni</h5>
                    <p style="font-style: italic; font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif">Supplier Sirup Lemon dengan <br>
                        Kualitas Tinggi</p>
                </div>

                <!-- Reseller Section -->
                <div class="col-md-3">
                    <h5 style="font-weight: bold;">Reseller</h5>
                    <ul class="list-unstyled">
                        <li><a style="text-decoration :none;" href="index" style="color: #ffffff;">Beranda</a></li>
                        <li><a style="text-decoration :none;" href="produk" style="color: #ffffff;">Produk Kami</a></li>
                        <li><a style="text-decoration :none;" href="testi" style="color: #ffffff;">Ulasan</a></li>
                        <li><a style="text-decoration :none;" href="cek" style="color: #ffffff;">Cek Pesanan</a></li>
                    </ul>
                </div>

                <!-- Informasi Section -->
                <div class="col-md-3">
                    <h5 style="font-weight: bold;">Informasi</h5>
                    <ul class="list-unstyled">
                        <li><a style="text-decoration :none;" href="#tentang-kami" style="color: #ffffff;">Tentang Kami</a></li>
                        <li><a style="text-decoration :none;" href="#" style="color: #ffffff;">Syarat & Ketentuan</a></li>
                        <li><a style="text-decoration :none;" href="#" style="color: #ffffff;">Kebijakan Privasi</a></li>
                    </ul>
                </div>

                <!-- Kontak Section -->
                <div class="col-md-3">
                    <h5 style="font-weight: bold;">Kontak</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt"></i> Jl. Pijer Podi No.117, Sempakata, Kec. Medan Selayang, Kota Medan, Sumatera Utara 20132</li>
                        <li><i class="fas fa-phone-alt"></i><a href="https://wa.me/082362584235" style="text-decoration :none;"> +62 823-6258-4235</a></li>
                    </ul>
                    <div class="social-icons">
                        <a href="#" style="color: #ffffff; margin-right: 10px;"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" style="color: #ffffff; margin-right: 10px;"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" style="color: #ffffff; margin-right: 10px;"><i class="fab fa-twitter fa-lg"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center" style="margin-top: 20px;">
            <p>&copy; 2024 Dapur Yoeni. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- Link ke JavaScript Bootstrap dan AOS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>