-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2024 at 09:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dapur_yoeni`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(50, 'Minuman'),
(58, 'Snack');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `id` int(11) NOT NULL,
  `order_id` varchar(20) DEFAULT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `status_bayar` enum('Belum Bayar','Lunas','Dibatalkan') DEFAULT 'Belum Bayar',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status_pesanan` enum('Pending','Sedang Diproses','Dalam Pengiriman','Selesai','Dibatalkan') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id`, `order_id`, `nama`, `alamat`, `no_hp`, `total_harga`, `status_bayar`, `created_at`, `status_pesanan`) VALUES
(91, 'ORD70003', 'afafaf', 'agag', '24253', 120000.00, 'Lunas', '2024-12-25 14:43:48', 'Sedang Diproses'),
(92, 'ORD69666', 'r2r2', 'qgag', '23425', 120000.00, '', '2024-12-25 14:44:51', 'Pending'),
(93, 'ORD14131', 'WILLIAM SEBASTIAN L. TOBING ', 'agaagag', '2352525', 170000.00, 'Belum Bayar', '2024-12-25 14:52:56', 'Pending'),
(94, 'ORD68607', 'WILLIAM SEBASTIAN L. TOBING ', 'agaagag', '2352525', 170000.00, 'Lunas', '2024-12-25 14:53:41', 'Selesai'),
(95, 'ORD45910', 'afaag', 'absb', '2626', 120000.00, 'Lunas', '2024-12-25 16:09:28', 'Selesai'),
(96, 'ORD16072', 'giono', 'pws', '41515', 180000.00, 'Lunas', '2024-12-25 16:25:58', 'Selesai'),
(97, 'ORD78812', 'nananan', 'kakakka', '35255', 120000.00, 'Belum Bayar', '2024-12-25 16:32:31', 'Pending'),
(98, 'ORD34879', 'caca', 'naamamama', '35525255', 230000.00, 'Lunas', '2024-12-25 16:37:19', 'Pending'),
(99, 'ORD12911', 'aagag', 'shsfhzh', '466346', 80000.00, 'Lunas', '2024-12-25 16:52:13', 'Selesai'),
(100, 'ORD85559', 'faf', 'afafaff', '252525', 180000.00, 'Lunas', '2024-12-26 16:53:10', 'Selesai'),
(101, 'ORD73620', 'andi', 'supriadi', '01928291928', 80000.00, 'Belum Bayar', '2024-12-27 07:13:16', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `kategori_id` int(11) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `harga` double DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `detail` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `kategori_id`, `nama`, `harga`, `gambar`, `detail`) VALUES
(17, 50, 'Sirup Lemon 90mL', 90000, 'lemon2.jpg', 'Sirup lemon dibuat dengan lemon pilihan agar tercipta rasa yang menakjubkan'),
(18, 50, 'Jus Lemon', 40000, 'lemon3.jpg', 'Jus lemon dengan cita rasa yang menakjubkan'),
(19, 58, 'Stik Keju', 20000, 'stikkeju.jpg', 'Stik Keju dengan rasa yang menggoda'),
(20, 58, 'Keripik Sukun', 40000, 'krikun.jpg', 'Keripik renyah dari buah sukun berkualitas'),
(21, 58, 'Srimcis', 40000, 'srimcis.jpg', 'Srimcis enak lezat');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` between 1 and 5),
  `comment` text NOT NULL,
  `date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `rating`, `comment`, `date`) VALUES
(1, 'Muhammad Fikri', 5, 'Sirup lemon ini sangat segar dan pas untuk diminum setiap hari!', '2024-12-24 23:15:54'),
(2, 'Aisyah Nur', 4, 'Rasa asamnya cocok untuk detox tubuh. Recommended!', '2024-12-24 23:15:54'),
(3, 'Budi Santoso', 3, 'Rasanya cukup enak, tapi terlalu manis untuk saya.', '2024-12-24 23:15:54'),
(4, 'Clara Devi', 5, 'Sirup lemon terbaik yang pernah saya coba, cocok untuk berbagai minuman.', '2024-12-24 23:15:54'),
(5, 'Diana Putri', 2, 'Tidak sesuai dengan ekspektasi, terlalu encer.', '2024-12-24 23:15:54'),
(6, 'William Sebastian', 5, 'Mantap', '2024-12-24 23:38:26'),
(7, 'Bambang Suseno', 4, 'Rasanya pas di lidah', '2024-12-25 19:41:43');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_detail_pesanan`
--

CREATE TABLE `tabel_detail_pesanan` (
  `id` int(11) NOT NULL,
  `order_id` varchar(20) DEFAULT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tabel_detail_pesanan`
--

INSERT INTO `tabel_detail_pesanan` (`id`, `order_id`, `nama_produk`, `jumlah`, `harga`, `total`) VALUES
(131, 'ORD70003', 'Jus Lemon', 3, 40000.00, 120000.00),
(132, 'ORD69666', 'Jus Lemon', 3, 40000.00, 120000.00),
(133, 'ORD14131', 'Jus Lemon', 2, 40000.00, 80000.00),
(134, 'ORD14131', 'Sirup Lemon', 1, 90000.00, 90000.00),
(135, 'ORD68607', 'Jus Lemon', 2, 40000.00, 80000.00),
(136, 'ORD68607', 'Sirup Lemon', 1, 90000.00, 90000.00),
(137, 'ORD45910', 'Jus Lemon', 3, 40000.00, 120000.00),
(138, 'ORD16072', 'Sirup Lemon', 2, 90000.00, 180000.00),
(139, 'ORD78812', 'Jus Lemon', 3, 40000.00, 120000.00),
(140, 'ORD34879', 'Jus Lemon', 2, 40000.00, 80000.00),
(141, 'ORD34879', 'Stik Keju', 3, 20000.00, 60000.00),
(142, 'ORD34879', 'Sirup Lemon', 1, 90000.00, 90000.00),
(143, 'ORD12911', 'Jus Lemon', 2, 40000.00, 80000.00),
(144, 'ORD85559', 'Sirup Lemon', 2, 90000.00, 180000.00),
(145, 'ORD73620', 'Srimcis', 2, 40000.00, 80000.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$lSAORUJlAdgArT5ZtnR19uIBYhRaPBb44xF9RDcmd1icaK1k6fd.m');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nama` (`nama`),
  ADD KEY `kategori_produk` (`kategori_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_detail_pesanan`
--
ALTER TABLE `tabel_detail_pesanan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tabel_detail_pesanan`
--
ALTER TABLE `tabel_detail_pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `kategori_produk` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`);

--
-- Constraints for table `tabel_detail_pesanan`
--
ALTER TABLE `tabel_detail_pesanan`
  ADD CONSTRAINT `tabel_detail_pesanan_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `pesanan` (`order_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
